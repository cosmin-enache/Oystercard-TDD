class Plane
end
